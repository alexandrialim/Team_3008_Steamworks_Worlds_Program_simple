package org.usfirst.frc.team3008.robot;

import org.usfirst.frc.team3008.robot.Robot;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.Spark;
import org.usfirst.frc.team3008.robot.Winch1;
import org.usfirst.frc.team3008.robot.Winch2;
import org.usfirst.frc.team3008.robot.Vars;


public class Driver implements Vars
{
	Joystick joyDriver;
	
	boolean running = true;
	boolean threadStarted = false;
	boolean m_running_auton = false;
	Robot m_r;
	Winch1 winch1;
	Winch2 winch2;
	
	
	
	Driver(Robot r){
		m_r=r;
		winch1 = new Winch1();
		winch2 = new Winch2();
	}
	double remapAxis(double value)
    {
	 	final int axis_map[] = {
	 	         2,    4,    6,    8,   10,   12,   14,   16,   18,   20,
	 	        22,   25,   27,   29,   32,   34,   37,   39,   42,   44,
	 	        47,   50,   52,   55,   58,   61,   64,   67,   70,   73,
	 	        77,   80,   83,   87,   90,   94,   97,  101,  105,  109,
	 	       113,  117,  121,  125,  129,  134,  138,  143,  147,  152,
	 	       157,  162,  167,  172,  177,  183,  188,  194,  200,  205,
	 	       212,  218,  224,  231,  237,  244,  251,  258,  265,  273,
	 	       280,  288,  296,  304,  313,  321,  330,  339,  348,  358,
	 	       368,  378,  388,  398,  409,  420,  432,  443,  455,  468,
	 	       480,  493,  507,  520,  534,  549,  564,  579,  595,  611,
	 	       628,  645,  662,  680,  699,  718,  738,  759,  779,  801,
	 	       823,  846,  870,  894,  920,  946,  972,  1000,  1000};
	 	
	 	
        int t=1; //* Mapping function is symmetric. only store pos half  *//
        int Scaled= (int) (value * 127.0); //Get whole number 0-127
        if (Scaled < 0) {   //* Check here if the input value is negative*//
           Scaled *= -1;    //* take the absolute value                  *//
           t=-1;            //* remember to invert the result            *//
           Scaled += 1;     //* correction to allow 100% power           *//
        }else{
           Scaled += 1;     //* correction to allow 100% power since     *//
        }
        if (Scaled < 11) {return 0.0; } //* deadband removal             *//
        Scaled -= 11;         //* deadband values not included in table  *//
        t *= axis_map[Scaled]; //* lookup value and correct for negative *//
        return ((double)t)/1000.0; //* Convert to 0-1 value              *//
    } 
 

	double normal(double x)
	{
		if (x>1)x=1;
		if(x<-1)x=-1;
		if((x<0.1)&&(x>-0.1))x=0;
		return x;
	}
	
	    static Spark FR = new Spark(rightFrontDrive);
	    static Spark FL = new Spark(leftFrontDrive);
	    static Spark BR = new Spark(rightRearDrive);
	    static Spark BL = new Spark(leftRearDrive);
	    double FR2=0;
	    double FL2=0;
	    double BR2=0;
	    double BL2=0;
	

	
	
	public void calc_drive(double x, double x2, double y)
	 {
		 
		  FR2  =(y +x2 + x); 
		  BR2  =(y +x2 - x); 
		  FL2  =(y -x2 + x); 
		  BL2  =(y -x2 - x); 
		  
		    FR.set(FR2);
	    	FL.set(FL2);
	    	BR.set(BR2);
	    	BL.set(BL2);
			 
		 
	 }
	

	Thread drive = new Thread(new Runnable()
	 {
		@Override
		
		public void run() 
		{
			
			joyDriver = new Joystick(0);
			while (true)
			{
				while(running)
				{
					double x = joyDriver.getRawAxis(0);
					double y = joyDriver.getRawAxis(1);
					double x2 = joyDriver.getRawAxis(2);
					calc_drive(remapAxis(x),remapAxis(y),remapAxis(x2));
					
					if (joyDriver.getRawButton(6))winch1.set(-1);
					else winch1.set(0);
					
					if(joyDriver.getRawButton(6))winch2.set(1);
					else winch2.set(0);
						
				    	
		       	}
				
			}
		}
	 });

	
	public void start_auton() {
		// TODO Auto-generated method stub
		m_running_auton = true;
		 if (!threadStarted) {
			 drive.start();
		 }
		 threadStarted = true;
	}
	public void stop_auton() {
		// TODO Auto-generated method stub
		m_running_auton=false;
	}
	public void stop() {
		// TODO Auto-generated method stub
		running = false;
	}
	public void start() {
		// TODO Auto-generated method stub
		running = true;
		 if (!threadStarted) drive.start();
		 threadStarted = true;
	}
	
}