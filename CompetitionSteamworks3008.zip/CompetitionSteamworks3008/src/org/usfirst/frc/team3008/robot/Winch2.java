package org.usfirst.frc.team3008.robot;

import edu.wpi.first.wpilibj.Spark;

public class Winch2 implements Vars {
	
	//PIDMotor spokes;
	//Counter c;
	//double Kp,Ki,Kd;
	Spark winch2;
	public Winch2()
	{
		//c= new Counter(feederEncoder);
		//spokes= new PIDMotor(feederMotor,c,PIDSourceType.kRate,false,Kp,Ki,Kd,0);
		//spokes.reset();
		//spokes.enable();
		winch2 = new Spark(winchMotor2);
		
	}

	
	void set(double speed)
	{
		winch2.set(speed);
		//spokes.PIDset(speed);
	}
	
	
	
	
}
