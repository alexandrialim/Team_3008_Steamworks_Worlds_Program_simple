package org.usfirst.frc.team3008.robot;

import org.usfirst.frc.team3008.robot.AutoChooser.AutoMode;

import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

public class AutoChooser {

	public static enum AutoMode {
	 Center, Left, Right;
	}
	
	AutoMode mode;
	private final SendableChooser<AutoMode> chooser;   
	
		public AutoChooser() {

		chooser = new SendableChooser<AutoMode>();
		chooser.addDefault("Center", AutoMode.Center);
		chooser.addObject("Left", AutoMode.Left);
		chooser.addObject("Right", AutoMode.Right);
	}
	
	public void putChoosersOnDash(){
		SmartDashboard.putData("Auto_Mode_Chooser ", chooser);
		
	}

	 public AutoMode getAutoChoice() {
		return (AutoMode)chooser.getSelected();
	}

}
	
