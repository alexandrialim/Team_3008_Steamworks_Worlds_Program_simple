
package org.usfirst.frc.team3008.robot;

import edu.wpi.first.wpilibj.CameraServer;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.SampleRobot;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.command.Scheduler;
import org.usfirst.frc.team3008.robot.AutoChooser;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import org.usfirst.frc.team3008.robot.Vars;


public class Robot extends SampleRobot implements Vars {
//naming autoChooser to having
//Command autonomousCommand;
RobotDrive drive;
	
//public static AutoChooser autoChooser = new AutoChooser();
//AutoChooser.AutoMode mode = Robot.autoChooser.getAutoChoice();

//AutonDriver Mechanum = new AutonDriver();  
Driver Mechanum = new Driver(this);

//VictorSP belts =new VictorSP(injesterMotor);
    
  
    
    public Robot() 
    {  
    	
    }
    
    public void robotInit() 
    {

    	try{
    	CameraServer.getInstance().startAutomaticCapture();
    	System.out.println( "Cam0");
    	}catch
    		(Exception e) {
    		System.out.println();
    		}
    	
    }

	{
		Timer.delay(0.05);
	}


	public void autonomous() {
		//if (mode == AutoChooser.AutoMode.Left) {
		//Start Drive motors	(goes straight)	
/*			Driver.FR.set(-0.5); // or -0.4 or -0.45 (needs to test)
			Driver.FL.set(0.5);
			Driver.BR.set(-0.5);
			Driver.BL.set(0.5);
			Timer.delay(1.13); //goes straight for 1.4 seconds.
			
			Driver.FR.set(0.5); // turn to the right (needs to turn 45 degrees to the right)
			Driver.FL.set(0.5);
			Driver.BR.set(0.5);
			Driver.BL.set(0.5);
			Timer.delay(0.37);//turns for 0.3 seconds.
			
			Driver.FR.set(-0.5); // or -0.4 or -0.45 (needs to test) [goes straight]
			Driver.FL.set(0.5);
			Driver.BR.set(-0.5);
			Driver.BL.set(0.5);
			Timer.delay(1.37);//goes straight for 0.3 seconds.
			
			//Stop Drive motors (stops at / near peg) [needs testing] 
			Driver.FR.set(0);
			Driver.FL.set(0);
			Driver.BR.set(0);
			Driver.BL.set(0);
		}
		
*/
	//{
	//if (mode == AutoChooser.AutoMode.Center) {
		
	/*		//Start Drive motors		
			Driver.FR.set(-0.5); // or -0.4 or -0.45 (needs to test)
			Driver.FL.set(0.5);
			Driver.BR.set(-0.5);
			Driver.BL.set(0.5);
			Timer.delay(1.5); //goes straight for 1.5 seconds.
			//Stop Drive motors (stops at / near peg) [needs testing] 
			Driver.FR.set(0);
			Driver.FL.set(0);
			Driver.BR.set(0);
			Driver.BL.set(0);
				
	}	*/
	//}
		//}
	//if ( mode == AutoChooser.AutoMode.Right) {
		
	//Start Drive motors	(goes straight)	
		Driver.FR.set(-0.5); // or -0.4 or -0.45 (needs to test)
		Driver.FL.set(0.5);
		Driver.BR.set(-0.5);
		Driver.BL.set(0.5);
		Timer.delay(1.35); //goes straight for 1.4 seconds.
		
		Driver.FR.set(-0.5); // turn to the left (needs to turn 45 degrees to the left)
		Driver.FL.set(-0.5);
		Driver.BR.set(-0.5);
		Driver.BL.set(-0.5);
		Timer.delay(0.34);//turns for 0.4 seconds.
		
		Driver.FR.set(-0.5); // or -0.4 or -0.45 (needs to test) [goes straight]
		Driver.FL.set(0.5);
		Driver.BR.set(-0.5);
		Driver.BL.set(0.5);
		Timer.delay(1.18);//goes straight for 0.3 seconds.
		
		//Stop Drive motors (stops at / near peg) [needs testing] 
		Driver.FR.set(0);
		Driver.FL.set(0);
		Driver.BR.set(0);
		Driver.BL.set(0);
	}

	
    public void operatorControl() 
    {
    	
    	
  
    	Timer.delay(1);
  		Mechanum.start();
  		
  		//Joystick joyOperator1 = new Joystick (1);
  		while (isOperatorControl() && isEnabled()) 
		{
  			//if (joyOperator1.getRawButton(2))belts.set(0.85);
  			//else belts.set(0.0);
			Timer.delay(0.01);
			
			
		
			
	    	
		}
		Mechanum.stop();
		
			
			
    }

    
    public void test()
    {
    	
    }
/*public void autonomousInit(){
	autonomousCommand = (Command) autoChooser.getSelected();
	autonomousCommand.start();
}*/
//public void autonomousPeriodic(){
//	Scheduler.getInstance().run();
//}

   }