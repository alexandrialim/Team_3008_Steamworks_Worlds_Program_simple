package org.usfirst.frc.team3008.robot;

import edu.wpi.first.wpilibj.Spark;

public class Winch1 implements Vars {
	
	//PIDMotor spokes;
	//Counter c;
	//double Kp,Ki,Kd;
	Spark winch1;
	public Winch1()
	{
		//c= new Counter(feederEncoder);
		//spokes= new PIDMotor(feederMotor,c,PIDSourceType.kRate,false,Kp,Ki,Kd,0);
		//spokes.reset();
		//spokes.enable();
		winch1 = new Spark(winchMotor1);
		
	}

	

	
	void set(double speed)
	{
		winch1.set(speed);
		//spokes.PIDset(speed);
	}
	
	
	
	
}
