package org.usfirst.frc.team3008.robot;


public interface Vars 
{
	
	
	
	
//	   _______          ____  __ 
//	  |  __ \ \        / /  \/  |
//	  | |__) \ \  /\  / /| \  / |
//	  |  ___/ \ \/  \/ / | |\/| |
//	  | |      \  /\  /  | |  | |
//	  |_|       \/  \/   |_|  |_|
//	                          
	                             


//////////////////////////////////////////////////////////
														//
	static final int winchMotor1 = 5;					//
	static final int winchMotor2 = 6;					//
//////////////////////////////////////////////////////////	
	static final int leftFrontDrive  = 1;				//
	static final int rightFrontDrive = 3;				//
	static final int leftRearDrive = 0;					//
	static final int rightRearDrive = 2;				//
//////////////////////////////////////////////////////////	
	
	
	
/*    
DDDDDDDDDDDDD      IIIIIIIIII     OOOOOOOOO     
D::::::::::::DDD   I::::::::I   OO:::::::::OO   
D:::::::::::::::DD I::::::::I OO:::::::::::::OO 
DDD:::::DDDDD:::::DII::::::IIO:::::::OOO:::::::O
D:::::D    D:::::D   I::::I  O::::::O   O::::::::O
D:::::D     D:::::D  I::::I  O:::::O     O:::::;:O
D:::::D     D:::::D  I::::I  O:::::O     O:::::;:O
D:::::D     D:::::D  I::::I  O:::::O     O::::;::O
D:::::D     D:::::D  I::::I  O:::::O     O::::;::O
D:::::D     D:::::D  I::::I  O:::::O     O:::::::O
D:::::D     D:::::D  I::::I  O:::::O     O:::::::O
D:::::D    D:::::D   I::::I  O::::::O   O::::::::O
DDD:::::DDDDD:::::DII::::::IIO:::::::OOO:::::::O
D:::::::::::::::DD I::::::::I OO:::::::::::::OO 
D::::::::::::DDD   I::::::::I   OO:::::::::OO   
DDDDDDDDDDDDD      IIIIIIIIII     OOOOOOOOO     

	
////////////////////////////////////////////////////////////*/
						
//////////////////////////////////////////////////////////////
	static final int leftFrontDriveEncA = 2;				//
	static final int rightFrontDriveEncA = 6;				//switching 4&8 ports
	static final int leftRearDriveEncA = 0;					//
	static final int rightRearDriveEncA = 4;				//
															//
	static final int leftFrontDriveEncB = 3;				//
	static final int rightFrontDriveEncB = 7;				//
	static final int leftRearDriveEncB = 1;					//switching 5&9 ports
	static final int rightRearDriveEncB = 5;				//
//////////////////////////////////////////////////////////////
			
//////////////////////////////////////////////////////////////
}
